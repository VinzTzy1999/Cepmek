//my secript by @zexxobreewc
//not sale this script

require("./database/module")

//GLOBAL PAYMENT
global.storename = "ཀ͜͡༑ཀ   ⃟ᮡᮁཫ᭺𝐙𝐞⃟𝐗𝐱⃟𝐨`𝐁𝐫𝐞𝐞𝐰𝐜⃟᷍ཀ🩸 𝐯7.1ཀ͜͡🇬🇧"
global.dana = "085691056438"
global.qris = "chat admin"


// GLOBAL SETTING
global.owner = "6285691056438"
global.namabot = "ཀ͜͡༑ཀ   ⃟ᮡᮁཫ᭺𝐙𝐞⃟𝐗𝐱⃟𝐨`𝐁𝐫𝐞𝐞𝐰𝐜⃟᷍ཀ🩸 𝐯7.1ཀ͜͡🇬🇧"
global.nomorbot = "6285604283229"
global.nameCreator = "ཀ͜͡༑ཀ   ⃟ᮡᮁཫ᭺𝐙𝐞⃟𝐗𝐱⃟𝐨 𝐯7.1ཀ͜͡🇬🇧"
global.linkyt = "https://www.youtube.com/@Zexxorasher66"
global.autoJoin = false
global.antilink = true
global.versisc = '7.1'

// DELAY JPM
global.delayjpm = 5500



//GLOBAL THUMB

global.codeInvite = ""
global.imageurl = 'https://files.catbox.moe/rm8b02.jpg'
global.isLink = "https://www.youtube.com/@Zexxorasher66"
global.packname = "ཀ͜͡༑ཀ   ⃟ᮡᮁཫ᭺𝐙𝐞⃟𝐗𝐱⃟𝐨`𝐁𝐫𝐞𝐞𝐰𝐜⃟᷍ཀ🩸 𝐯7ཀ͜͡🇬🇧"
global.author = "ཀ͜͡༑ཀ   ⃟ᮡᮁཫ᭺𝐙𝐞⃟𝐗𝐱⃟𝐨`𝐁𝐫𝐞𝐞𝐰𝐜⃟᷍ཀ🩸 𝐯7ཀ͜͡🇬🇧"
global.jumlah = "5"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})